<?php

/* ModelBundle:Index:index.html.twig */
class __TwigTemplate_6f4051c14e6f608292d9c57423aa9574e0d352ceee07ed621cbc6f928776077a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "ModelBundle:Index:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_162857b081bbd5c3533d853b6a12000ccbed5c0f8a1ebad5e8a132ce81a56fa0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_162857b081bbd5c3533d853b6a12000ccbed5c0f8a1ebad5e8a132ce81a56fa0->enter($__internal_162857b081bbd5c3533d853b6a12000ccbed5c0f8a1ebad5e8a132ce81a56fa0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ModelBundle:Index:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_162857b081bbd5c3533d853b6a12000ccbed5c0f8a1ebad5e8a132ce81a56fa0->leave($__internal_162857b081bbd5c3533d853b6a12000ccbed5c0f8a1ebad5e8a132ce81a56fa0_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_5a0c58826300b10c1d6437871f8c9bc7f0af70df90d2b642e683ea675a6189c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a0c58826300b10c1d6437871f8c9bc7f0af70df90d2b642e683ea675a6189c8->enter($__internal_5a0c58826300b10c1d6437871f8c9bc7f0af70df90d2b642e683ea675a6189c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Index";
        
        $__internal_5a0c58826300b10c1d6437871f8c9bc7f0af70df90d2b642e683ea675a6189c8->leave($__internal_5a0c58826300b10c1d6437871f8c9bc7f0af70df90d2b642e683ea675a6189c8_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_66e7db6b73a1db49ad0503fa98a16317e5df65a3eba564a990320762069303c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66e7db6b73a1db49ad0503fa98a16317e5df65a3eba564a990320762069303c0->enter($__internal_66e7db6b73a1db49ad0503fa98a16317e5df65a3eba564a990320762069303c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "<h1>Index</h1>
   ";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["posts"] ?? $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 8
            echo "       ";
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "
       ";
            // line 9
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["post"], "autor", array()), "nome", array()), "html", null, true);
            echo "
       <!--slice corta o texto-->
       ";
            // line 11
            echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["post"], "content", array()), 0, 45), "html", null, true);
            echo "
       <a href=\"";
            // line 12
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("show", array("id" => $this->getAttribute($context["post"], "id", array()))), "html", null, true);
            echo "\">... Leia mais</a><br>
   ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_66e7db6b73a1db49ad0503fa98a16317e5df65a3eba564a990320762069303c0->leave($__internal_66e7db6b73a1db49ad0503fa98a16317e5df65a3eba564a990320762069303c0_prof);

    }

    public function getTemplateName()
    {
        return "ModelBundle:Index:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 12,  70 => 11,  65 => 9,  60 => 8,  56 => 7,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::base.html.twig\" %}

{% block title %}Index{% endblock %}

{% block content %}
<h1>Index</h1>
   {% for post in posts %}
       {{ post.title }}
       {{ post.autor.nome }}
       <!--slice corta o texto-->
       {{ post.content | slice(0,45) }}
       <a href=\"{{ path('show', {'id': post.id}) }}\">... Leia mais</a><br>
   {% endfor  %}
{% endblock %}
", "ModelBundle:Index:index.html.twig", "/vox/meuProjeto/src/MHAN/ModelBundle/Resources/views/Index/index.html.twig");
    }
}
