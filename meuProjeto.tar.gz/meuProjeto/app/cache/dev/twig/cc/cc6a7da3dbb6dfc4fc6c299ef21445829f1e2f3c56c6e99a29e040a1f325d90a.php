<?php

/* TwigBundle:Exception:exception_full.html.twig */
class __TwigTemplate_47ace1cad848ae2f86c69ed6dc9fd603ec2f045f0404c9cdd7fa88e37459c87d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("TwigBundle::layout.html.twig", "TwigBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "TwigBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_97dabe5f4571e4a1a11c6ea0f5e10f07baf0fbf81cf5e79f6c637f48ae220dcf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_97dabe5f4571e4a1a11c6ea0f5e10f07baf0fbf81cf5e79f6c637f48ae220dcf->enter($__internal_97dabe5f4571e4a1a11c6ea0f5e10f07baf0fbf81cf5e79f6c637f48ae220dcf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_97dabe5f4571e4a1a11c6ea0f5e10f07baf0fbf81cf5e79f6c637f48ae220dcf->leave($__internal_97dabe5f4571e4a1a11c6ea0f5e10f07baf0fbf81cf5e79f6c637f48ae220dcf_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_d02c62e9a3cac2af37cc4bf5bee7ff6f14c32b07ec7e6671ea4d9044d992f29f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d02c62e9a3cac2af37cc4bf5bee7ff6f14c32b07ec7e6671ea4d9044d992f29f->enter($__internal_d02c62e9a3cac2af37cc4bf5bee7ff6f14c32b07ec7e6671ea4d9044d992f29f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_d02c62e9a3cac2af37cc4bf5bee7ff6f14c32b07ec7e6671ea4d9044d992f29f->leave($__internal_d02c62e9a3cac2af37cc4bf5bee7ff6f14c32b07ec7e6671ea4d9044d992f29f_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_e46f0c265e980bc408d7dc0bd82885a163bbb5f5600a7b0927add4980427cd69 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e46f0c265e980bc408d7dc0bd82885a163bbb5f5600a7b0927add4980427cd69->enter($__internal_e46f0c265e980bc408d7dc0bd82885a163bbb5f5600a7b0927add4980427cd69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["exception"] ?? $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, ($context["status_code"] ?? $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["status_text"] ?? $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_e46f0c265e980bc408d7dc0bd82885a163bbb5f5600a7b0927add4980427cd69->leave($__internal_e46f0c265e980bc408d7dc0bd82885a163bbb5f5600a7b0927add4980427cd69_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_c75798d86479dbc6d53cc7df2825e9b0f49ef9fbf5c85b5048c0b82ac2d2fabb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c75798d86479dbc6d53cc7df2825e9b0f49ef9fbf5c85b5048c0b82ac2d2fabb->enter($__internal_c75798d86479dbc6d53cc7df2825e9b0f49ef9fbf5c85b5048c0b82ac2d2fabb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("TwigBundle:Exception:exception.html.twig", "TwigBundle:Exception:exception_full.html.twig", 12)->display($context);
        
        $__internal_c75798d86479dbc6d53cc7df2825e9b0f49ef9fbf5c85b5048c0b82ac2d2fabb->leave($__internal_c75798d86479dbc6d53cc7df2825e9b0f49ef9fbf5c85b5048c0b82ac2d2fabb_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'TwigBundle::layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include 'TwigBundle:Exception:exception.html.twig' %}
{% endblock %}
", "TwigBundle:Exception:exception_full.html.twig", "/vox/meuProjeto/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception_full.html.twig");
    }
}
