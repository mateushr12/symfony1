<?php

/* ModelBundle:Autor:show.html.twig */
class __TwigTemplate_bca701c0df0f35881ebe864f7718d4945b01c85b848c084d606a378e7bf0c8d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "ModelBundle:Autor:show.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e0df0e4218b5b9bc2086c31a297ed5ad59a7d40ee3328859e1e119c0600b9d80 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e0df0e4218b5b9bc2086c31a297ed5ad59a7d40ee3328859e1e119c0600b9d80->enter($__internal_e0df0e4218b5b9bc2086c31a297ed5ad59a7d40ee3328859e1e119c0600b9d80_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ModelBundle:Autor:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e0df0e4218b5b9bc2086c31a297ed5ad59a7d40ee3328859e1e119c0600b9d80->leave($__internal_e0df0e4218b5b9bc2086c31a297ed5ad59a7d40ee3328859e1e119c0600b9d80_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_c21b3320c43d4b6b6c2b96d340961d6ab9c67491452b38a21b64e251f242f9a5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c21b3320c43d4b6b6c2b96d340961d6ab9c67491452b38a21b64e251f242f9a5->enter($__internal_c21b3320c43d4b6b6c2b96d340961d6ab9c67491452b38a21b64e251f242f9a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Autor</h1>

    <table class=\"record_properties\">
        <tbody>
            <tr>
                <th>Id</th>
                <td>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute(($context["entity"] ?? $this->getContext($context, "entity")), "id", array()), "html", null, true);
        echo "</td>
            </tr>
            <tr>
                <th>Nome</th>
                <td>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute(($context["entity"] ?? $this->getContext($context, "entity")), "nome", array()), "html", null, true);
        echo "</td>
            </tr>
        </tbody>
    </table>

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("autor");
        echo "\">
            Back to the list
        </a>
    </li>
    <li>
        <a href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("autor_edit", array("id" => $this->getAttribute(($context["entity"] ?? $this->getContext($context, "entity")), "id", array()))), "html", null, true);
        echo "\">
            Edit
        </a>
    </li>
    <li>";
        // line 30
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["delete_form"] ?? $this->getContext($context, "delete_form")), 'form');
        echo "</li>
</ul>
";
        
        $__internal_c21b3320c43d4b6b6c2b96d340961d6ab9c67491452b38a21b64e251f242f9a5->leave($__internal_c21b3320c43d4b6b6c2b96d340961d6ab9c67491452b38a21b64e251f242f9a5_prof);

    }

    public function getTemplateName()
    {
        return "ModelBundle:Autor:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 30,  73 => 26,  65 => 21,  55 => 14,  48 => 10,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block body -%}
    <h1>Autor</h1>

    <table class=\"record_properties\">
        <tbody>
            <tr>
                <th>Id</th>
                <td>{{ entity.id }}</td>
            </tr>
            <tr>
                <th>Nome</th>
                <td>{{ entity.nome }}</td>
            </tr>
        </tbody>
    </table>

        <ul class=\"record_actions\">
    <li>
        <a href=\"{{ path('autor') }}\">
            Back to the list
        </a>
    </li>
    <li>
        <a href=\"{{ path('autor_edit', { 'id': entity.id }) }}\">
            Edit
        </a>
    </li>
    <li>{{ form(delete_form) }}</li>
</ul>
{% endblock %}
", "ModelBundle:Autor:show.html.twig", "/vox/meuProjeto/src/MHAN/ModelBundle/Resources/views/Autor/show.html.twig");
    }
}
