<?php

/* ModelBundle:Postar:new.html.twig */
class __TwigTemplate_6ce938b96818d8cc697eed2f3790a962f3d7822c8aa04382fd4e7c9c7d15203b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "ModelBundle:Postar:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d9044ce32bc04172c867fad3922707cc4ab906e1c07628ae2c4283742bb98b9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9044ce32bc04172c867fad3922707cc4ab906e1c07628ae2c4283742bb98b9e->enter($__internal_d9044ce32bc04172c867fad3922707cc4ab906e1c07628ae2c4283742bb98b9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ModelBundle:Postar:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d9044ce32bc04172c867fad3922707cc4ab906e1c07628ae2c4283742bb98b9e->leave($__internal_d9044ce32bc04172c867fad3922707cc4ab906e1c07628ae2c4283742bb98b9e_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_feaa0586476475933bff2cce6695c4f6e7e8842d2f4749c65139774d4980cfe4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_feaa0586476475933bff2cce6695c4f6e7e8842d2f4749c65139774d4980cfe4->enter($__internal_feaa0586476475933bff2cce6695c4f6e7e8842d2f4749c65139774d4980cfe4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Postar creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("postar");
        echo "\">
            Back to the list
        </a>
    </li>
</ul>
";
        
        $__internal_feaa0586476475933bff2cce6695c4f6e7e8842d2f4749c65139774d4980cfe4->leave($__internal_feaa0586476475933bff2cce6695c4f6e7e8842d2f4749c65139774d4980cfe4_prof);

    }

    public function getTemplateName()
    {
        return "ModelBundle:Postar:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block body -%}
    <h1>Postar creation</h1>

    {{ form(form) }}

        <ul class=\"record_actions\">
    <li>
        <a href=\"{{ path('postar') }}\">
            Back to the list
        </a>
    </li>
</ul>
{% endblock %}
", "ModelBundle:Postar:new.html.twig", "/vox/meuProjeto/src/MHAN/ModelBundle/Resources/views/Postar/new.html.twig");
    }
}
