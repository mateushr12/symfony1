<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_95c246ac83367f95fa19ecc340528e296f7a6ae9e4b10711370b87b98e1a66d6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e5faeb99c770a288d1237eaade56a7cf6563fbd08a837dfc36721f08f5ca565b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5faeb99c770a288d1237eaade56a7cf6563fbd08a837dfc36721f08f5ca565b->enter($__internal_e5faeb99c770a288d1237eaade56a7cf6563fbd08a837dfc36721f08f5ca565b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e5faeb99c770a288d1237eaade56a7cf6563fbd08a837dfc36721f08f5ca565b->leave($__internal_e5faeb99c770a288d1237eaade56a7cf6563fbd08a837dfc36721f08f5ca565b_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_ce931f3144adb689b4741c795e07eac2537e92b9a4fa775a11306b7f72b5aba4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce931f3144adb689b4741c795e07eac2537e92b9a4fa775a11306b7f72b5aba4->enter($__internal_ce931f3144adb689b4741c795e07eac2537e92b9a4fa775a11306b7f72b5aba4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_ce931f3144adb689b4741c795e07eac2537e92b9a4fa775a11306b7f72b5aba4->leave($__internal_ce931f3144adb689b4741c795e07eac2537e92b9a4fa775a11306b7f72b5aba4_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"FOSUserBundle::layout.html.twig\" %}

{% block fos_user_content %}
{% include \"FOSUserBundle:Registration:register_content.html.twig\" %}
{% endblock fos_user_content %}
", "FOSUserBundle:Registration:register.html.twig", "/vox/meuProjeto/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/Registration/register.html.twig");
    }
}
