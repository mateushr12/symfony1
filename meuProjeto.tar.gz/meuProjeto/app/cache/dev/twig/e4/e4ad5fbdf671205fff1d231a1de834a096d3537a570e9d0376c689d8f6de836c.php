<?php

/* FOSUserBundle::layout.html.twig */
class __TwigTemplate_982b5e7bd815d8f0fbf000f9e5362055de2c8b2315172e4c2cb642b881075be5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "FOSUserBundle::layout.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a0d7c5a4d9a149f3f8ac828ebabfd34e34dba0ee3a5c088588d7066ba743b887 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a0d7c5a4d9a149f3f8ac828ebabfd34e34dba0ee3a5c088588d7066ba743b887->enter($__internal_a0d7c5a4d9a149f3f8ac828ebabfd34e34dba0ee3a5c088588d7066ba743b887_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a0d7c5a4d9a149f3f8ac828ebabfd34e34dba0ee3a5c088588d7066ba743b887->leave($__internal_a0d7c5a4d9a149f3f8ac828ebabfd34e34dba0ee3a5c088588d7066ba743b887_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_b458a847bb2c3cf27f6a1036d47f137812cb0877ac5561bf99d6e5c4af4ef885 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b458a847bb2c3cf27f6a1036d47f137812cb0877ac5561bf99d6e5c4af4ef885->enter($__internal_b458a847bb2c3cf27f6a1036d47f137812cb0877ac5561bf99d6e5c4af4ef885_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Admin";
        
        $__internal_b458a847bb2c3cf27f6a1036d47f137812cb0877ac5561bf99d6e5c4af4ef885->leave($__internal_b458a847bb2c3cf27f6a1036d47f137812cb0877ac5561bf99d6e5c4af4ef885_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_cb366f3815e5487d8b20336c694971c25e60dba4879e2db6a06800181c9b65a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb366f3815e5487d8b20336c694971c25e60dba4879e2db6a06800181c9b65a9->enter($__internal_cb366f3815e5487d8b20336c694971c25e60dba4879e2db6a06800181c9b65a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "    ";
        $this->displayBlock('fos_user_content', $context, $blocks);
        
        $__internal_cb366f3815e5487d8b20336c694971c25e60dba4879e2db6a06800181c9b65a9->leave($__internal_cb366f3815e5487d8b20336c694971c25e60dba4879e2db6a06800181c9b65a9_prof);

    }

    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_1c70a08cd5aca1a52bbe8e4b02c4011e8266caca224645240f74c241babc4531 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c70a08cd5aca1a52bbe8e4b02c4011e8266caca224645240f74c241babc4531->enter($__internal_1c70a08cd5aca1a52bbe8e4b02c4011e8266caca224645240f74c241babc4531_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        
        $__internal_1c70a08cd5aca1a52bbe8e4b02c4011e8266caca224645240f74c241babc4531->leave($__internal_1c70a08cd5aca1a52bbe8e4b02c4011e8266caca224645240f74c241babc4531_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 6,  48 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block title %}Admin{% endblock %}

{% block content %}
    {% block fos_user_content %}{% endblock %}
{% endblock %}

", "FOSUserBundle::layout.html.twig", "/vox/meuProjeto/vendor/friendsofsymfony/user-bundle/FOS/UserBundle/Resources/views/layout.html.twig");
    }
}
