<?php

/* ModelBundle:Autor:new.html.twig */
class __TwigTemplate_05acfd303244b88ec65fd99df5ce174454c485562c8cad3821f29d9945dab78b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "ModelBundle:Autor:new.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4e29a425de85a6392670a3fad76791e9250e3dcb9cb69df9cfde5253bd4eabab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e29a425de85a6392670a3fad76791e9250e3dcb9cb69df9cfde5253bd4eabab->enter($__internal_4e29a425de85a6392670a3fad76791e9250e3dcb9cb69df9cfde5253bd4eabab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ModelBundle:Autor:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4e29a425de85a6392670a3fad76791e9250e3dcb9cb69df9cfde5253bd4eabab->leave($__internal_4e29a425de85a6392670a3fad76791e9250e3dcb9cb69df9cfde5253bd4eabab_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_785397d0156552e287cafca25bfb7e6a79dd46abc8a72d6dd57586a4296b2d4c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_785397d0156552e287cafca25bfb7e6a79dd46abc8a72d6dd57586a4296b2d4c->enter($__internal_785397d0156552e287cafca25bfb7e6a79dd46abc8a72d6dd57586a4296b2d4c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "<h1>Autor creation</h1>

    ";
        // line 6
        echo         $this->env->getExtension('Symfony\Bridge\Twig\Extension\FormExtension')->renderer->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form');
        echo "

        <ul class=\"record_actions\">
    <li>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("autor");
        echo "\">
            Back to the list
        </a>
    </li>
</ul>
";
        
        $__internal_785397d0156552e287cafca25bfb7e6a79dd46abc8a72d6dd57586a4296b2d4c->leave($__internal_785397d0156552e287cafca25bfb7e6a79dd46abc8a72d6dd57586a4296b2d4c_prof);

    }

    public function getTemplateName()
    {
        return "ModelBundle:Autor:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 10,  44 => 6,  40 => 4,  34 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '::base.html.twig' %}

{% block body -%}
    <h1>Autor creation</h1>

    {{ form(form) }}

        <ul class=\"record_actions\">
    <li>
        <a href=\"{{ path('autor') }}\">
            Back to the list
        </a>
    </li>
</ul>
{% endblock %}
", "ModelBundle:Autor:new.html.twig", "/vox/meuProjeto/src/MHAN/ModelBundle/Resources/views/Autor/new.html.twig");
    }
}
