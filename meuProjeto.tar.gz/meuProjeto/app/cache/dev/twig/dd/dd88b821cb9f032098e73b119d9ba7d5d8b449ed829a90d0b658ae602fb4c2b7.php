<?php

/* ::base.html.twig */
class __TwigTemplate_b5b548104744ef4665f9393057e48b9d83814f517cf4f267803352f147fe2a4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'content' => array($this, 'block_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_446802f58c9de713d577a54fdb4fed9959038876e154ebee124e876dd3321992 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_446802f58c9de713d577a54fdb4fed9959038876e154ebee124e876dd3321992->enter($__internal_446802f58c9de713d577a54fdb4fed9959038876e154ebee124e876dd3321992_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 9
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 12
        $this->displayBlock('body', $context, $blocks);
        // line 23
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 24
        echo "    </body>
</html>
";
        
        $__internal_446802f58c9de713d577a54fdb4fed9959038876e154ebee124e876dd3321992->leave($__internal_446802f58c9de713d577a54fdb4fed9959038876e154ebee124e876dd3321992_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_5927db0a3468245d7f9e0255a4523c0e1c70be5328be0a09e211639515d17190 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5927db0a3468245d7f9e0255a4523c0e1c70be5328be0a09e211639515d17190->enter($__internal_5927db0a3468245d7f9e0255a4523c0e1c70be5328be0a09e211639515d17190_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Projeto teste";
        
        $__internal_5927db0a3468245d7f9e0255a4523c0e1c70be5328be0a09e211639515d17190->leave($__internal_5927db0a3468245d7f9e0255a4523c0e1c70be5328be0a09e211639515d17190_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_a0ed2409e27c4d454bf6542603a28069954636977cec4c032264728aefaa26cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a0ed2409e27c4d454bf6542603a28069954636977cec4c032264728aefaa26cd->enter($__internal_a0ed2409e27c4d454bf6542603a28069954636977cec4c032264728aefaa26cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/mhan/css/teste.css"), "html", null, true);
        echo "\" />
        ";
        
        $__internal_a0ed2409e27c4d454bf6542603a28069954636977cec4c032264728aefaa26cd->leave($__internal_a0ed2409e27c4d454bf6542603a28069954636977cec4c032264728aefaa26cd_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_978249823ee63bf2b650028d7817a8d242164aecef954a0c6c6e76dcb21e12d5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_978249823ee63bf2b650028d7817a8d242164aecef954a0c6c6e76dcb21e12d5->enter($__internal_978249823ee63bf2b650028d7817a8d242164aecef954a0c6c6e76dcb21e12d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "            <div class=\"container\">
                <header><h2>Teste</h2></header>
                <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\">Home</a> |
                <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_registration_register");
        echo "\">Cadastrar</a> |
                <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("fos_user_security_login");
        echo "\">Logar</a>
                ";
        // line 18
        $this->displayBlock('content', $context, $blocks);
        // line 20
        echo "                <footer><p>Rodape -teste</p></footer>
            </div>
        ";
        
        $__internal_978249823ee63bf2b650028d7817a8d242164aecef954a0c6c6e76dcb21e12d5->leave($__internal_978249823ee63bf2b650028d7817a8d242164aecef954a0c6c6e76dcb21e12d5_prof);

    }

    // line 18
    public function block_content($context, array $blocks = array())
    {
        $__internal_75246fc29ac3acc2de0522e727e773e8faad5c3a83d4bf8d7189dea109813249 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_75246fc29ac3acc2de0522e727e773e8faad5c3a83d4bf8d7189dea109813249->enter($__internal_75246fc29ac3acc2de0522e727e773e8faad5c3a83d4bf8d7189dea109813249_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 19
        echo "                ";
        
        $__internal_75246fc29ac3acc2de0522e727e773e8faad5c3a83d4bf8d7189dea109813249->leave($__internal_75246fc29ac3acc2de0522e727e773e8faad5c3a83d4bf8d7189dea109813249_prof);

    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_166ad4e08368c81dfc05cd960398151f4a0410218e53a5069afdc8e26f73cceb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_166ad4e08368c81dfc05cd960398151f4a0410218e53a5069afdc8e26f73cceb->enter($__internal_166ad4e08368c81dfc05cd960398151f4a0410218e53a5069afdc8e26f73cceb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_166ad4e08368c81dfc05cd960398151f4a0410218e53a5069afdc8e26f73cceb->leave($__internal_166ad4e08368c81dfc05cd960398151f4a0410218e53a5069afdc8e26f73cceb_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  134 => 23,  127 => 19,  121 => 18,  112 => 20,  110 => 18,  106 => 17,  102 => 16,  98 => 15,  94 => 13,  88 => 12,  78 => 7,  72 => 6,  60 => 5,  51 => 24,  48 => 23,  46 => 12,  39 => 9,  37 => 6,  33 => 5,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Projeto teste{% endblock %}</title>
        {% block stylesheets %}
            <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('bundles/mhan/css/teste.css') }}\" />
        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}
            <div class=\"container\">
                <header><h2>Teste</h2></header>
                <a href=\"{{ path('index') }}\">Home</a> |
                <a href=\"{{ path('fos_user_registration_register') }}\">Cadastrar</a> |
                <a href=\"{{ path('fos_user_security_login') }}\">Logar</a>
                {% block content %}
                {% endblock %}
                <footer><p>Rodape -teste</p></footer>
            </div>
        {% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "/vox/meuProjeto/app/Resources/views/base.html.twig");
    }
}
