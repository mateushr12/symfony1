<?php

namespace MHAN\ModelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ModelBundle extends Bundle
{
}
