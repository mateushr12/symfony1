<?php

namespace MHAN\ModelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

class IndexController extends Controller
{
    /**
     * @Route("/", name="index")
     * @Template()
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();
        $posts = $em->getRepository('ModelBundle:Postar')->findAllEmOrdem();
        return [
            'posts' => $posts,
        ];
     }

    /**
     * @Route("/show/{id}", name="show")
     * @Template()
     */
    public function showAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $post = $em->getRepository('ModelBundle:Postar')->find($id);
        if (!$post){
            throw $this->createNotFoundException('Post não existe');
        }
        return [
            'post' => $post,
        ];
    }

}
