<?php

namespace MHAN\PrimeiroBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PrimeiroBundle extends Bundle
{
}
